# Not available in this repo use @UploadLinkToFileBot this bot support mdisk link ✅💯
# Only paid user support mdisk link ✅
# Per month just $0.50/₹10 💸
# Bot username @UploadLinkToFileBot 🤖
# Check bot /plans and upgrade your subscription
# Please donate you can send any amount 💰
