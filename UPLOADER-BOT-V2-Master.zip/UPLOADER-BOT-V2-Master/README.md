# UPLOADER V2 🚀

[![logo](https://c.tenor.com/FU4mw1elg4QAAAAd/blackpink-kpop.gif)](https://telegram.dog/UploadLinkToFileBot)

[![GitHub forks](https://img.shields.io/github/forks/LISA-KOREA/UPLOADER-BOT-V2?&style=flat-square&logo=github)](https://github.com/LISA-KOREA/UPLOADER-BOT-V2/fork)
![Repo Size](https://img.shields.io/github/repo-size/LISA-KOREA/UPLOADER-BOT-V2?&style=flat-square&logo=github)
[![GitHub stars](https://img.shields.io/github/stars/LISA-KOREA/UPLOADER-BOT-V2?&style=flat-square&logo=github)](https://github.com/LISA-KOREA/UPLOADER-BOT-V2/stargazers)

  
# GIVE ME A STAR ⭐

### Fork And Deploy

  ㅤ ㅤ   ㅤ <a href="https://github.com/LISA-KOREA/UPLOADER-BOT-V2/fork"><img alt="Fork and deploy" src="https://img.shields.io/badge/-Fork%20And%20Deploy-black?style=for-the-badge&logo=github&logoColor=white"/></a> 



### Deploy To Heroku (No warranty)

  ㅤ ㅤ   ㅤ <a href="https://dashboard.heroku.com/new?template=https%3A%2F%2Fgithub.com%2FLISA-KOREA%2FUPLOADER-BOT-V2"><img alt="heroku" src="https://img.shields.io/badge/-Deploy%20To%20Heroku-purple?style=for-the-badge&logo=heroku&logoColor=white"/></a> 

### Deploy to Koyeb

  ㅤ ㅤ   ㅤ <a href="https://app.koyeb.com/deploy?type=git&repository=github.com/LISA-KOREA/UPLOADER-BOT-V2&branch=Master&name=uploaderbotv2"><img alt="heroku" src="https://img.shields.io/badge/-Deploy%20To%20Koyeb-black?style=for-the-badge&logo=koyeb&logoColor=white"/></a> 

#### How To Create Your Own Watch This Video 

<a href="https://youtu.be/UcRYSUdaFlo"><img src="https://img.shields.io/badge/How%20To%20Deploy-blue.svg?logo=Youtube"></a>

<a href="https://youtu.be/UcRYSUdaFlo"><img src="https://img.shields.io/youtube/views/UcRYSUdaFlo?style=social">

#### How to create mongoDB url video [YouTube Link](https://youtu.be/VudXkbirhM8)

## 

### Use this bot [Upload Bot V3.7 🚀](http://t.me/UploadLinkToFileBot)

##

### Config Vars:

1. `API_ID` : Get it from https://my.telegram.org/apps 
2. `API_HASH` : Get it from https://my.telegram.org/apps
3. `BOT_TOKEN` : Get it from [@Botfather](https://t.me/botfather)
4. `DATABASE_URL` : Your mongodb url obtained from [mongodb.com](https://www.mongodb.com)
5. `OWNER_ID` : Your telegram I'd use this bot [@UploadLinkToFileBot](https://telegram.dog/UploadLinkToFileBot) and use `/info`





## Credits, and Thanks to

* [@SpEcHlDe](https://t.me/ThankTelegram) for his [AnyDLBot](https://telegram.dog/AnyDLBot)
* [Dan Tès](https://t.me/haskell) for his [Pyrogram Library](https://github.com/pyrogram/pyrogram)
* [Yoily](https://t.me/YoilyL) for his [UploaditBot](https://telegram.dog/UploaditBot)
* [Lisa](https://t.me/LISA_FAN_LK) this is me [Upload Bot V3.7 🚀](https://telegram.dog/UploadLinkToFileBot)
